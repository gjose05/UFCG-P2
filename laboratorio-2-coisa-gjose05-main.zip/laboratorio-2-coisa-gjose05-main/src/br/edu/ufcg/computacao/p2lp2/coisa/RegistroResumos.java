package br.edu.ufcg.computacao.p2lp2.coisa;

/** 
 * esse programa registra os resumos dos alunos, a quantidade definida e seu conteudo
 * @author guilherme.jose.araujo.oliveira
 */
public class RegistroResumos {
	/**
	 * define inicialmente, as variaveis que serão utilizadas posteriormente, como a quantidade total disponivel para registrar
	 * a quantidade ja registrada
	 * os conteudos de cada resumo
	 * as materias dos resumos
	 */
	private int QntResumos;
	private int contadorderesumos;
	private String[] conteudos;
	private String[] materias;
	
	public RegistroResumos(int QntResumos) {
		/**
		 * define nessa variavel o total disponivel para o registro dos resumos
		 */
		this.QntResumos = QntResumos;
		contadorderesumos = 0;
		materias = new String[QntResumos];
		conteudos = new String[QntResumos];
	}
	
	public void adiciona(String tema, String resumo) {
	/** 
	 * utiliza a tecnica mode para obedecer a problematica da questao de substituir o resumo caso a quantidade seja ultrapassada
	 * adiciona o tema e o conteudo do resumo em suas respectivas posições do array
	 */
		int i = contadorderesumos % QntResumos;
		materias[i] = tema;
		conteudos[i] = resumo;
		if (contadorderesumos != QntResumos) {
			contadorderesumos++;
		}
	}
	
	public String[] pegaResumos() {
		/**
		 * retorna um array que combina o conteudo e o tema dos resumos
		 */
		String [] lista = new String[contadorderesumos];
		for (int i = 0 ; i < contadorderesumos; i++) {
			lista[i] = materias[i] + ": " + conteudos[i];
		}
		return lista;
	}

	public String imprimeResumos() {
		/** 
		 * retorna a quantidade de todos os resumos ja definidos pelo aluno e os reus respectivos nomes
		 */
		String nome = "";
		for (int i = 0 ; i < contadorderesumos ; i++) {
			if (i < contadorderesumos - 1) {
				nome += materias[i] + " | ";
			}
			else {
				nome += materias[i];
			}
		}
		return "- " + contadorderesumos + " resumo(s) cadastrado(s)" + "\n" + "- " + nome;
	}
	
	public int conta() {
		/** 
		 * retorna a quantidade de resumos ja definidos
		 */
		if (contadorderesumos >= QntResumos) 
			return QntResumos;
		
		else 
			return contadorderesumos;
	}
	
	public boolean temResumo(String tema) {
		/** 
		 * retorna como verdadeiro caso a variavel tema esteja contida no array de nomes ja definidos, caso o contrario o metodo retorna como falso
		 */
		for (int i = 0 ; i < contadorderesumos; i++) {
			if (materias[i].equals(tema)){
				return true;
			}
		}
		return false;
		
	}

}
